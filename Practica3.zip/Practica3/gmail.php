<?php
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;

    require_once __DIR__ . '/vendor/autoload.php';

    $correo = new PHPMailer(true);
    $correo->isSMTP(); 
    $correo->SMTPAuth = true; 
    $correo->SMTPSecure = 'ssl'; 
    $correo->Port = 465; 
    $correo->Host = 'smtp.gmail.com'; 
    $correo->Username = 'bmangel2004@gmail.com'; 
    $correo->Password = 'irdcvvvzuqoklitm'; 

    function comprobar($mail){
        return preg_match("/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/",$mail);
    }

    function enviarCorreo($c,$cuerpo){
        $correo = $c;
        $correo->setFrom('bmangel2004@gmail.com', 'Errores programa php'); 
        $correo->addAddress("bmangel2004@gmail.com");
        $correo->Subject = "Error"; 
        $correo->isHTML(true); 
        $correo->Body = $cuerpo; 
        $correo->send();
    }

    class archivoNoExiste extends Exception {}
    enviarCorreo($correo,$errores);
?>